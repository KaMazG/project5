﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace project5
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

       public long SearchElem;
        List<long> elems = new List<long>() {1,1};

        private void AcceptButton_Click(object sender, RoutedEventArgs e)
        {
            long temp = 0;
            SearchElem = int.Parse(ElemTextBox.Text);
            for(int i = 2; i < SearchElem; i++)
            {
                temp = elems[i - 2] + elems[i - 1];
                elems.Add(temp);
            }
            if (ElemTextBox.Text == "0" | ElemTextBox.Text == "1")
                AnswerBlock.Text = "1";
            else
                AnswerBlock.Text = temp.ToString();
        }
    }
}
